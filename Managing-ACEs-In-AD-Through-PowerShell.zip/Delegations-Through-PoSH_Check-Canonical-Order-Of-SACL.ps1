# Clear The Screen
Clear-Host

# Get The UI Config
$uiConfig = (Get-Host).UI.RawUI
$uiConfig.ForegroundColor = "Yellow"

# Import The Required Module
Import-Module ActiveDirectory

#Get The RootDSE Info
$rootDSE = Get-ADRootDSE

# Get List Of OUs In AD Domain
$listOfOUsToProcess = Get-ADOrganizationalUnit -Filter * | %{$_.DistinguishedName}

# Process Each OU
$OUsWithSACLInCanonicalOrder = @()
$OUsWithSACLNOTInCanonicalOrder = @()
$listOfOUsToProcess | %{
	$ou = $_
	$ouDrivePath = $("AD:\" + $ou)
	$aclOU = Get-Acl $ouDrivePath -Audit
	If ($aclOU.AreAuditRulesCanonical) {
		$ouObj = "" | Select "List Of OUs That DO Have The SACL In Canonical Order"
		$ouObj."List Of OUs That DO Have The SACL In Canonical Order" = $ou
		$OUsWithSACLInCanonicalOrder += $ouObj
	}
	If (!$aclOU.AreAuditRulesCanonical) {
		$ouObj = "" | Select "List Of OUs That DO NOT Have The SACL In Canonical Order"
		$ouObj."List Of OUs That DO NOT Have The SACL In Canonical Order" = $ou
		$OUsWithSACLNOTInCanonicalOrder += $ouObj
	}
}
$uiConfig.ForegroundColor = "Red"
If ($OUsWithSACLNOTInCanonicalOrder.Count -eq 0) {
	$ouObj = "" | Select "List Of OUs That DO NOT Have The SACL In Canonical Order"
	$ouObj."List Of OUs That DO NOT Have The SACL In Canonical Order" = "+++ NONE +++"
	$OUsWithSACLNOTInCanonicalOrder += $ouObj
}
$OUsWithSACLNOTInCanonicalOrder | FT -Autosize
$uiConfig.ForegroundColor = "Green"
If ($OUsWithSACLInCanonicalOrder.Count -eq 0) {
	$ouObj = "" | Select "List Of OUs That DO Have The SACL In Canonical Order"
	$ouObj."List Of OUs That DO Have The SACL In Canonical Order" = "+++ NONE +++"
	$OUsWithSACLInCanonicalOrder += $ouObj
}
$OUsWithSACLInCanonicalOrder | FT -Autosize
$uiConfig.ForegroundColor = "Yellow"