# Clear The Screen
Clear-Host

# Get Script Location
$scriptFolder = (Get-Location).Path

# Get File With OUs To Process
$fileWithListOfOUsToProcess = "List-Of-OUs-To-Process-For-Delegations.txt"

# Import The Required Module
Import-Module ActiveDirectory

#Get The RootDSE Info
$rootDSE = Get-ADRootDSE

# Get List Of OUs To Process
$listOfOUsToProcess = Get-Content $($scriptFolder + "\" + $fileWithListOfOUsToProcess)

# Security Principal To Audit For Actions
$securityPrincipalAccount = "ADCORP\MyDelegatedAdminGroup"

# Process Each OU
$listOfOUsToProcess | %{
	$ou = $_
	$ouDrivePath = $("AD:\" + $ou)
	Write-Host ""
	Write-Host "Processing OU: $ou" -Foregroundcolor Cyan
	Write-Host "   REMOVING Audit Entries..."
	Write-Host "      Security Principal...: $securityPrincipalAccount"
	Write-Host ""
	$aclOU = Get-Acl $ouDrivePath -Audit
	$aclOU.Audit | ?{$_.IdentityReference -eq $securityPrincipalAccount} | %{
		$auditRule = $_
		$aclOU.RemoveAuditRule($auditRule)
	}
	$aclOU | Set-Acl $ouDrivePath
}