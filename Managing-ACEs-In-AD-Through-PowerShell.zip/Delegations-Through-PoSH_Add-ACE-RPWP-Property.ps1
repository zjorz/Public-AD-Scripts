# Clear The Screen
Clear-Host

# Get Script Location
$scriptFolder = (Get-Location).Path

# Get File With OUs To Process
$fileWithListOfOUsToProcess = "List-Of-OUs-To-Process-For-Delegations.txt"

# Import The Required Module
Import-Module ActiveDirectory

#Get The RootDSE Info
$rootDSE = Get-ADRootDSE

# Create Hash Table With The lDAPDisplayName And schemaIDGUID Of Each Schema Class And Attribute
$mappingTable_lDAPDisplayName_schemaIDGUID = @{}
Get-ADObject -SearchBase $($rootDSE.schemaNamingContext) `
	-LDAPFilter "(schemaIDGUID=*)" `
	-Properties lDAPDisplayName,schemaIDGUID | %{
		$mappingTable_lDAPDisplayName_schemaIDGUID[$_.lDAPDisplayName]=[System.GUID]$_.schemaIDGUID
	}

# Get List Of OUs To Process
$listOfOUsToProcess = Get-Content $($scriptFolder + "\" + $fileWithListOfOUsToProcess)

# Object Class And Attribute To Assign Permissions For 
$scopedObject = "user"
$schemaIDGUIDScopedObject = $mappingTable_lDAPDisplayName_schemaIDGUID[$scopedObject]
$scopedAttribute = "employeeID"
$schemaIDGUIDScopedAttribute = $mappingTable_lDAPDisplayName_schemaIDGUID[$scopedAttribute]
$inheritanceScope = "Descendents"

# Security Principal To Assign Permissions To
$securityPrincipalAccount = "ADCORP\MyDelegatedAdminGroup"
$securityPrincipalObject = New-Object System.Security.Principal.NTAccount($securityPrincipalAccount)

# Define ACE
$rightsCollection = [System.DirectoryServices.ActiveDirectoryRights]::"ReadProperty","WriteProperty"
$aclType = [System.Security.AccessControl.AccessControlType]::"Allow"
$aceDefinition = $securityPrincipalObject,$rightsCollection,$aclType,$schemaIDGUIDScopedAttribute,$inheritanceScope,$schemaIDGUIDScopedObject
$accessRule = New-Object System.DirectoryServices.ActiveDirectoryAccessRule($aceDefinition)

# Process Each OU
$listOfOUsToProcess | %{
	$ou = $_
	$ouDrivePath = $("AD:\" + $ou)
	Write-Host ""
	Write-Host "Processing OU: $ou" -Foregroundcolor Cyan
	Write-Host "   ADDING ACE..."
	Write-Host "      Security Principal...: $securityPrincipalAccount"
	Write-Host "      ACL Type.............: $aclType"
	Write-Host "      Access Type..........: $rightsCollection"
	Write-Host "      Scoped Attribute.....: $scopedAttribute"
	Write-Host "      Scoped Object Class..: $scopedObject"
	Write-Host "      Scope................: $inheritanceScope"
	Write-Host ""
	$aclOU = Get-Acl $ouDrivePath
	$aclOU.AddAccessRule($accessRule)
	$aclOU | Set-Acl $ouDrivePath
}