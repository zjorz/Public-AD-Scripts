# Clear The Screen
Clear-Host

# Get The UI Config
$uiConfig = (Get-Host).UI.RawUI
$uiConfig.ForegroundColor = "Yellow"

# Import The Required Module
Import-Module ActiveDirectory

#Get The RootDSE Info
$rootDSE = Get-ADRootDSE

# Get List Of OUs In AD Domain
$listOfOUsToProcess = Get-ADOrganizationalUnit -Filter * | %{$_.DistinguishedName}

# Process Each OU
$OUsWithDACLInCanonicalOrder = @()
$OUsWithDACLNOTInCanonicalOrder = @()
$listOfOUsToProcess | %{
	$ou = $_
	$ouDrivePath = $("AD:\" + $ou)
	$aclOU = Get-Acl $ouDrivePath
	If ($aclOU.AreAccessRulesCanonical) {
		$ouObj = "" | Select "List Of OUs That DO Have The DACL In Canonical Order"
		$ouObj."List Of OUs That DO Have The DACL In Canonical Order" = $ou
		$OUsWithDACLInCanonicalOrder += $ouObj
	}
	If (!$aclOU.AreAccessRulesCanonical) {
		$ouObj = "" | Select "List Of OUs That DO NOT Have The DACL In Canonical Order"
		$ouObj."List Of OUs That DO NOT Have The DACL In Canonical Order" = $ou
		$OUsWithDACLNOTInCanonicalOrder += $ouObj
	}
}
$uiConfig.ForegroundColor = "Red"
If ($OUsWithDACLNOTInCanonicalOrder.Count -eq 0) {
	$ouObj = "" | Select "List Of OUs That DO NOT Have The DACL In Canonical Order"
	$ouObj."List Of OUs That DO NOT Have The DACL In Canonical Order" = "+++ NONE +++"
	$OUsWithDACLNOTInCanonicalOrder += $ouObj
}
$OUsWithDACLNOTInCanonicalOrder | FT -Autosize
$uiConfig.ForegroundColor = "Green"
If ($OUsWithDACLInCanonicalOrder.Count -eq 0) {
	$ouObj = "" | Select "List Of OUs That DO NOT Have The DACL In Canonical Order"
	$ouObj."List Of OUs That DO NOT Have The DACL In Canonical Order" = "+++ NONE +++"
	$OUsWithDACLInCanonicalOrder += $ouObj
}
$OUsWithDACLInCanonicalOrder | FT -Autosize
$uiConfig.ForegroundColor = "Yellow"