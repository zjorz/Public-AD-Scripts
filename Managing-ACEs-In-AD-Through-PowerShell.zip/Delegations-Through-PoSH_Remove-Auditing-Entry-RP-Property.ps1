# Clear The Screen
Clear-Host

# Get Script Location
$scriptFolder = (Get-Location).Path

# Get File With OUs To Process
$fileWithListOfOUsToProcess = "List-Of-OUs-To-Process-For-Delegations.txt"

# Import The Required Module
Import-Module ActiveDirectory

#Get The RootDSE Info
$rootDSE = Get-ADRootDSE

# Create Hash Table With The lDAPDisplayName And schemaIDGUID Of Each Schema Class And Attribute
$mappingTable_lDAPDisplayName_schemaIDGUID = @{}
Get-ADObject -SearchBase $($rootDSE.schemaNamingContext) `
	-LDAPFilter "(schemaIDGUID=*)" `
	-Properties lDAPDisplayName,schemaIDGUID | %{
		$mappingTable_lDAPDisplayName_schemaIDGUID[$_.lDAPDisplayName]=[System.GUID]$_.schemaIDGUID
	}

# Get List Of OUs To Process
$listOfOUsToProcess = Get-Content $($scriptFolder + "\" + $fileWithListOfOUsToProcess)

# Object Class And Attribute To Configure Auditing For 
$scopedObject = "user"
$schemaIDGUIDScopedObject = $mappingTable_lDAPDisplayName_schemaIDGUID[$scopedObject]
$scopedAttribute = "employeeID"
$schemaIDGUIDScopedAttribute = $mappingTable_lDAPDisplayName_schemaIDGUID[$scopedAttribute]
$inheritanceScope = "Descendents"

# Security Principal To Audit For Actions
$securityPrincipalAccount = "ADCORP\MyDelegatedAdminGroup"
$securityPrincipalObject = New-Object System.Security.Principal.NTAccount($securityPrincipalAccount)

# Define Auditing Entry
$rightsCollection = [System.DirectoryServices.ActiveDirectoryRights]::"ReadProperty"
$auditType = [System.Security.AccessControl.AuditFlags]::"Success","Failure"
$auditDefinition = $securityPrincipalObject,$rightsCollection,$auditType,$schemaIDGUIDScopedAttribute,$inheritanceScope,$schemaIDGUIDScopedObject
$auditRule = New-Object System.DirectoryServices.ActiveDirectoryAuditRule($auditDefinition)

# Process Each OU
$listOfOUsToProcess | %{
	$ou = $_
	$ouDrivePath = $("AD:\" + $ou)
	Write-Host ""
	Write-Host "Processing OU: $ou" -Foregroundcolor Cyan
	Write-Host "   REMOVING Audit Entry..."
	Write-Host "      Security Principal...: $securityPrincipalAccount"
	Write-Host "      Audit Type...........: $auditType"
	Write-Host "      Access Type..........: $rightsCollection"
	Write-Host "      Scoped Attribute.....: $scopedAttribute"
	Write-Host "      Scoped Object Class..: $scopedObject"
	Write-Host "      Scope................: $inheritanceScope"
	Write-Host ""
	$aclOU = Get-Acl $ouDrivePath -Audit
	$aclOU.RemoveAuditRule($auditRule)
	$aclOU | Set-Acl $ouDrivePath
}